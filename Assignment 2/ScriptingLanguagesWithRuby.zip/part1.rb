# This is the original coin row given in prompt
coinRow = "  HHHHHTTTTT  "

# The number of moves the user can make
maxMoves = 5

# Represents an empty space to place coins in
emptySpace  = "--"

# Defines the string that saves the letter position to move
startPos = ""

# Defines the string that saves the final position to move to
finalPos = ""

# Defines the string that saves the coins to move such as "HT" or "TH"
coinsToMove = ""

# maxMoves decrements for each move made
while maxMoves > 0

	# prints amount of moves left
	puts "Amount of moves left", maxMoves

	# prints following directions with new line at end
	# asks user for leftmost coin character to move
	puts "Space underneath the letter of the leftmost character of the two coins you want to move"

	# prints the row of coin characters with new line at end
	puts coinRow
	
	# gets the string and saves to startPos
	startPos = gets
	
	# tests whether there is an "--" in the row of coins
	if coinRow.include? emptySpace then
		# loops if user tried to position space where there is no empty space
		while (startPos.size() - 1 == coinRow.index('-')) or (startPos.size() == coinRow.index('-') + 1)
			
			# prints following instruction with new line at end
			# reminds user that there is a space available and to use it
			puts "You cannot select that space as it is empty. Please space underneath a character such as 'H' or 'T' instead."

			# prints coinRow again with new line at the end
			puts coinRow

			# gets user input and saves to startPos
			startPos = gets
		end
	else
		# loop to catch incorrect space positioning for coin character 
		while startPos.size() < 3 or startPos.size > 12

			# prints following direction with new line at end
			# tells user to position space underneath a valid coin character
			puts "You did not position your space underneath a coin character. Please place space under an 'H' or a 'T'"

			# prints the coin row again with new line at end
			puts coinRow

			# gets user input and saves to startPos
			startPos = gets
		end
	end

	# prints following directions with new line at end
	# asks user to space to position to move to
	puts "Select position to move to by spacing to that position"
	
	# prints coinRow again with new line at the end
	puts coinRow
	
	# gets user input and saves to finalPos
	finalPos = gets
	
	# tests whether there is an "--" in the row of coins
	if coinRow.include? emptySpace then

		# loops if user tried to position space where there is no empty space
		while finalPos.size() - 1 != coinRow.index('-')
			
			# prints following instruction with new line at end
			# reminds user that there is a space available and to use it
			puts "You cannot position your space there because there is an empty space somewhere in the row. Use that empty space instead."

			# prints coinRow again with new line at the end
			puts coinRow

			# gets user input and saves to startPos
			finalPos = gets
		end
		
		# user has put position to valid space
		# the following steps are to move the 2 characters to the user desired location

		# gets substring from coinRow starting from the startPos to the next character and saves to coinsToMove
		coinsToMove = coinRow[(startPos.size() - 1)..startPos.size()]

		# splits coinRow into individual characters and saves to coinRowArray, includes the string "--" and empty strings " " if they exist
		coinRowArray = coinRow.split(//)

		# remove the original characters in the start position to move them from
		# inserts empty space to where the characters to move originally where using insert function 
		# first argument is the original start position, second argument is an '-'
		coinRowArray.delete_at(startPos.size())
		coinRowArray.delete_at(startPos.size() - 1)
		coinRowArray.insert(startPos.size() - 1, "-")
		coinRowArray.insert(startPos.size(), "-")

		# inserts coin characters to final position the user chose
		# first argument is the original start position, second argument is the first character of the coinsToMove string, e.g. the 'H' in "HT" or the 'T' in "TH"
		# first we must remove the characters at that position before inserting the new ones
		coinRowArray.delete_at(finalPos.size())
		coinRowArray.delete_at(finalPos.size() - 1)
		coinRowArray.insert(finalPos.size() - 1, coinsToMove[0..0])
		coinRowArray.insert(finalPos.size(), coinsToMove[1..1])

		# joins the elements in coinRowArray into one string and saves back to coinRow
		# it reflects the move the user decided on
		coinRow = coinRowArray.join()
	
	# if there is no empty space in the coin row, then the user is allowed to place the final position at the ends of the row
	else
		
		# the user must position the space to one of the ends, they cannot move characters into positions where other characters reside
		# loop until user places space in one of the ends
		while finalPos.size > 1 and finalPos.size < 14
			
			# prints following warning with new line
			# reminds user that there are no empty spaces and they must place at either end of the coin row
			puts "You cannot move those coins there. There is no empty space to put them. Please place the space at either ends of the coin row."

			# prints coinRow again with new line at the end
			puts coinRow

			# gets user input and saves to finalPos
			finalPos = gets
		end

		# user has put space in valid space at either ends
		# the following steps are to move the 2 characters to the user desired location

		# gets substring from coinRow starting from the startPos to the next character and saves to coinsToMove
		coinsToMove = coinRow[(startPos.size() - 1)..startPos.size()]
		
		# splits coinRow into individual characters and saves to coinRowArray, includes the string "--" and empty strings " " if they exist
		coinRowArray = coinRow.split(//)

		# remove the original characters in the start position to move them from
		# inserts empty space to where the characters to move originally where using insert function 
		# first argument is the original start position, second argument is an '-'
		coinRowArray.delete_at(startPos.size())
		coinRowArray.delete_at(startPos.size() - 1)
		coinRowArray.insert(startPos.size() - 1, "-")
		coinRowArray.insert(startPos.size(), "-")

		# inserts coin characters to final position the user chose
		# first argument is the original start position, second argument is the first character of the coinsToMove string, e.g. the 'H' in "HT" or the 'T' in "TH"
		# first we must remove the characters at that position before inserting the new ones
		coinRowArray.delete_at(finalPos.size())
		coinRowArray.delete_at(finalPos.size() - 1)
		coinRowArray.insert(finalPos.size() - 1, coinsToMove[0..0])
		coinRowArray.insert(finalPos.size(), coinsToMove[1..1])

		# joins the elements in coinRowArray into one string and saves back to coinRow
		# it reflects the move the user decided on
		coinRow = coinRowArray.join()
	
	end

	# decrements maxMoves by 1
	maxMoves -= 1
end

puts coinRow

# after all moves, checks whether user has one of the following patterns
if coinRow == "HTHTHTHTHT" or coinRow == "THTHTHTHTH" then

	# prints following statement with new line at end
	puts "Congratulations you won!"
else 

	# prints following statement with new line at end
	puts "Too bad. Bette luck next time."
end	

# ends the game with the following statement
puts "The game has ended."
