# gets the values from the user and makes it into an integer array

puts 'Input values separated by spaces: '
in_array = gets.chomp.split().map { |e| e.to_i  }
puts 'Input test value: '
test_value = gets.strip.to_i
puts 'Input the partition index value: '
partition_val = gets.strip.to_i

org_array = in_array
puts 'The original array was: '
print org_array
cLP = 0
cRP = in_array.length() - 1

# while the left partition index is less than the partition value
while cLP <= partition_val
	# if the left value is more than the the right one
	if in_array[cLP]. > in_array[cRP] then 
		# switch left and right
		in_array[cLP], in_array[cRP] = in_array[cRP], in_array[cLP]
	end
	# if the left is less than the test value
	if in_array[cLP] <= test_value then
		# move marker
		cLP += 1
	end
	# if the right is more than the test value
	if in_array[cRP] > test_value then
		# move marker
		cRP -= 1
	end
end

print "\n"
print 'The new array is: '
print "\n"
print in_array
print "\n"
print 'with partition value: '
puts partition_val
